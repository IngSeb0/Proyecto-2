package model.persistencia;

import model.Galeria;

public class CentralPersistencia {
	
	private Galeria galeria;
	
	public Galeria getGaleria() {
		return galeria;
	}

	public void setGaleria(Galeria galeria) {
		this.galeria = galeria;
	}

	public void cargarObjetos()
	{
		
	}
}
