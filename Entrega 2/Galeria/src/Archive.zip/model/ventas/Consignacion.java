package model.ventas;

public class Consignacion {

}
